# QET WEBSITE

QET Computer sysytems company website

## Objective
TBD


### Installation

```sh
$ git clone https://github.com/qet-devs/qet.git
```



### Run
https://qet-devs.github.io/qet/products.html


### Test

Acceptance Tests, Functional Tests and Unit Tests

```sh
$ coming soon
```

### Author
Isaac Ngeno - <isaac2ngeno5@gmail.com> 

### License
MIT License
